import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "node1/lab8p7/logs"


def read_results(filename):
    rows = []
    for line in (LOGS / filename).read_text().splitlines():
        fields = line.split()
        if (len(fields) != 5 or
                not fields[0].isdigit() or
                not fields[1].isdigit()):
            continue
        try:
            rows.append((
                int(fields[0]),
                int(fields[1]),
                *(float(value) for value in fields[2:])
            ))
        except ValueError:
            continue

    if not rows:
        raise SystemExit(f"No measurement rows found in {filename}")

    return sorted(rows)


def save_csv(filename, header, rows):
    with (ROOT / filename).open("w", newline="") as output:
        writer = csv.writer(output)
        writer.writerow(header)
        writer.writerows(rows)


proxy = read_results("gpu-lat-client.log")
direct = read_results("gpu-doorbell-client.log")
bandwidth = read_results("gpu-put-bw-client-repeat.log")

latency_header = [
    "message_bytes", "iterations", "latency_us",
    "round_trip_us", "cuda_kernel_us"
]
save_csv("gpu_latency_proxy.csv", latency_header, proxy)
save_csv("gpu_latency_direct.csv", latency_header, direct)
save_csv("gpu_bandwidth.csv", [
    "message_bytes", "iterations", "bandwidth_gbps",
    "message_rate_mpps", "cuda_kernel_ms"
], bandwidth)

fig, ax = plt.subplots(figsize=(8, 4.8))
for rows, label in [
    (proxy, "CPU proxy (-p 1)"),
    (direct, "Direct GPU doorbell (-p 2)")
]:
    ax.plot(
        [row[0] for row in rows],
        [row[2] for row in rows],
        marker="o", label=label
    )
ax.set_xscale("log", base=2)
ax.set(
    xlabel="Message size (bytes)",
    ylabel="One-way latency (µs)",
    title="GPUNetIO GPU-to-GPU RDMA latency"
)
ax.grid(True, which="both", alpha=0.3)
ax.legend()
fig.tight_layout()
fig.savefig(ROOT / "gpu_latency.png", dpi=200)
plt.close(fig)

fig, ax = plt.subplots(figsize=(8, 4.8))
ax.plot(
    [row[0] for row in bandwidth],
    [row[2] for row in bandwidth],
    marker="o", label="put_bw, CPU proxy (-p 1), GID 3"
)
ax.set_xscale("log", base=2)
ax.set(
    xlabel="Message size (bytes)",
    ylabel="Average bandwidth (Gbps)",
    title="GPUNetIO GPU-to-GPU RDMA bandwidth"
)
ax.grid(True, which="both", alpha=0.3)
ax.legend()
fig.tight_layout()
fig.savefig(ROOT / "gpu_bandwidth.png", dpi=200)
plt.close(fig)

print(f"CPU-proxy latency: {len(proxy)} measurement rows")
print(f"Direct-GPU latency: {len(direct)} measurement rows")
print(f"Validated bandwidth: {len(bandwidth)} measurement rows")
print("Saved three CSV files and two PNG plots in:", ROOT)
